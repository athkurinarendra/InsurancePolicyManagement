import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DeleteService } from '../delete.service';
import { Policy } from '../policy';
import { PolicyService } from '../policy.service';

@Component({
  selector: 'app-policy',
  templateUrl: './policy.component.html',
  styleUrls: ['./policy.component.css']
})
export class PolicyComponent implements OnInit {


  policiess : Policy[];
  constructor(private _policyService :PolicyService,private _deleteService :DeleteService,private router : Router) {

    this._policyService.showPolicies().subscribe({
      next: rs =>{
        this.policiess = rs;
      }
    })
   }

   policyid :  number;
   result: any;

   edit(pid : number){
    this.router.navigate(['/Update',pid]);
     
  }
  delete(pid : number){
    this.policyid=pid;
    localStorage.setItem("PolicyId",this.policyid.toString());
    this.router.navigate(['/Delete',pid]);
    

  }
  ngOnInit(): void {
  }

}
