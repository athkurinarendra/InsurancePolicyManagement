import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Policy } from '../policy';
import { PolicyService } from '../policy.service';

@Component({
  selector: 'app-editpolicy',
  templateUrl: './editpolicy.component.html',
  styleUrls: ['./editpolicy.component.css']
})
export class EditpolicyComponent implements OnInit {


  public editpolicy! : FormGroup;
policy : Policy;
result : any;


update(editpolicy : NgForm){
  this._policyService.updatepolicy(this.policy).subscribe(x =>{
    this.result=x;
})
console.log("policy = "+JSON.stringify(this.policy))
alert("Policy Updated Successfully!!")
this.router.navigate(['/adminDashboard'])
}

constructor(private _policyService : PolicyService,private router : Router, private route : ActivatedRoute) {
  this.policy = new Policy();
}


  ngOnInit(): void {
    let pid=parseInt(this.route.snapshot.params['pid'])

    this._policyService.getpolicy(pid).subscribe(x =>{
      this.policy=x;})



  }

}
