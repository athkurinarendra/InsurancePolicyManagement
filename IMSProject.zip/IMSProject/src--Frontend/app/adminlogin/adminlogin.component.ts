import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  public loginForm! : FormGroup
  constructor(private formBuilder : FormBuilder,private http : HttpClient,private router:Router) { }

  ngOnInit(): void {
this.loginForm = this.formBuilder.group({
  ausername : [''],
  apassword : ['']

})
  }
  onALogin(){
 this.http.get<any>("http://localhost:8080/admin")
 .subscribe(res=>{
   const user = res.find((a:any)=>{
     return a.ausername === this.loginForm.value.ausername && a.apassword === this.loginForm.value.apassword
   });
   if(user){
     alert("Login success...");
     localStorage.setItem('user1',JSON.stringify(user));
     this.loginForm.reset();
     this.router.navigate(['/AdminDashboard'])
   }else{
     alert("User not found...")
   }
 })
  }
  
}
