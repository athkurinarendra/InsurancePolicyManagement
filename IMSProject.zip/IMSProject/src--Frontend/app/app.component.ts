import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'IMS';
 /* loggedinUser:string ;*/

  constructor(private router:Router) {
  
   }

  ngOnInit(): void {
    
  }
  



// loggedin(){
//   /*this.loggedinUser = localStorage.getItem('user');*/
//   return localStorage.getItem('user');
// }
// csLoggedin(){
//   return localStorage.getItem('user1')
// }

// onLogout(){
//   if
//     (window.confirm('Are you sure , you want to logout')){
//       localStorage.removeItem('user');
//       localStorage.removeItem('user1');
//     }
    
//   }
  


  
}
