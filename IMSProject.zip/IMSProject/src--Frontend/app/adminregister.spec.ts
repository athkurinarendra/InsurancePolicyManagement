import { Adminregister } from './adminregister';

describe('Adminregister', () => {
  it('should create an instance', () => {
    expect(new Adminregister()).toBeTruthy();
  });
});
