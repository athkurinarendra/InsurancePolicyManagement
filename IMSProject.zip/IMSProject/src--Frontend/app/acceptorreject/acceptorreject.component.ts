import { Component, OnInit } from '@angular/core';
import { ApoliciesService } from '../apolicies.service';

@Component({
  selector: 'app-acceptorreject',
  templateUrl: './acceptorreject.component.html',
  styleUrls: ['./acceptorreject.component.css']
})
export class AcceptorrejectComponent implements OnInit {

  aid : number;
  status : string;
  result : string;
  acceptOrReject() {
    this._appliedpolicyService.acceptOrReject(this.aid,this.status).subscribe(
      x =>{
        this.result = x;
      }
    )
    alert("Policy status Changed..");
  }

  constructor(private _appliedpolicyService : ApoliciesService) {
    this.aid = parseInt(localStorage.getItem("ApplicationId"));
   }
  ngOnInit(): void {
  }

}
