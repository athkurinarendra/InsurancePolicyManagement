import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Policy } from '../policy';
import { PolicyService } from '../policy.service';

@Component({
  selector: 'app-addpolicy',
  templateUrl: './addpolicy.component.html',
  styleUrls: ['./addpolicy.component.css']
})
export class AddpolicyComponent implements OnInit {
  public addpolicy! : FormGroup;
policy : Policy;
result : any;


insert(addpolicy : NgForm){
  this._policyService.addpolicy(this.policy).subscribe(x =>{
    this.result=x;
})
alert("Policy Added Successfully!!")
this.router.navigate(['/adminDashboard'])
}

constructor(private _policyService : PolicyService,private router : Router) {
  this.policy = new Policy();
}

  ngOnInit(): void {
  }

}
