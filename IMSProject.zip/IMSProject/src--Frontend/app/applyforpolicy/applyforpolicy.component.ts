import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Apolicies } from '../apolicies';
import { ApoliciesService } from '../apolicies.service';
import { Policy } from '../policy';
import { PolicyService } from '../policy.service';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-applyforpolicy',
  templateUrl: './applyforpolicy.component.html',
  styleUrls: ['./applyforpolicy.component.css']
})
export class ApplyforpolicyComponent implements OnInit {

  public applypolicy! : FormGroup;
  apolicy : Apolicies;
  policy : Policy;
  user : User;
  result : any;
  custId : number;
  custName : string;
  reason: string;
  constructor(private _apolicyService : ApoliciesService,private _policyService : PolicyService,private _userService : UserService,private router : Router,private route : ActivatedRoute) {
    this.apolicy = new Apolicies();

   }
  insert(applypolicy : NgForm){
    this._apolicyService.applypolicy(this.apolicy).subscribe(x =>{
      this.result=x;
  })
  // alert(this.policy.pname);
  alert("Policy Applied Successfully!!")
this.router.navigate(['/userDashboard'])
  }

  

  ngOnInit(): void {
    let pid=parseInt(this.route.snapshot.params['pid'])

      this._policyService.getpolicy(pid).subscribe(x =>{
      this.policy=x;
      this.apolicy.pname = this.policy.pname;
      // console.log("policy = "+JSON.stringify(this.policy))
    })

      let user2 = JSON.parse(localStorage.getItem("user2"))
      this.custId = parseInt(user2.custId)

      this._userService.getcustomer(this.custId).subscribe(x =>{
        this.user=x;})


        this.apolicy.custId = user2.custId;
        this.apolicy.custName = user2.custName;




      
      
  }

}
