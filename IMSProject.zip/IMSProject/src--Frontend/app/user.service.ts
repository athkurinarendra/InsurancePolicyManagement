import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private _http: HttpClient) { }
  showUser(): Observable<User []> {
    return this._http.get<User []>("http://localhost:8080/Customer")
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
}

adduser(user : User) : Observable<any> {
  return this._http.post<string>("http://localhost:8080/adduser",user).
  pipe(tap(data => data.toString()))
}

getcustomer(custId : number) : Observable<User>{
  return this._http.get<User>("http://localhost:8080/Customer/" + custId)
}
updateuser(user : User) : Observable<any> {
  return this._http.put<string>("http://localhost:8080/edituser",user).
  pipe(tap(data => data.toString()))
}


}
