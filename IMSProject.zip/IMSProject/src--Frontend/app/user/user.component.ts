import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  users : User[];
  custId : number;
  constructor(private _userService :UserService,private router : Router) {

    this._userService.showUser().subscribe({
      next: rs =>{
        this.users = rs;
      }
    })
    let user2 = JSON.parse(localStorage.getItem("user2"))
    this.custId = parseInt(user2.custId)
   
   }

   delete(custId : number){
    this.router.navigate(['/DeleteCustomer',custId]);
  }
  ngOnInit(): void {
  }

}
