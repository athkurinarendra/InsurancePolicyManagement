import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { Policy } from './policy';

@Injectable({
  providedIn: 'root'
})
export class DeleteService {

  constructor(private _http: HttpClient) { }


  deletepolicy(pid : number) : Observable<any> {
    return this._http.delete<string>("http://localhost:8080/delete/"+ pid).
    pipe(tap(data => data.toString()))
  }

  deleteuser(custId : number) : Observable<any> {
    return this._http.delete<string>("http://localhost:8080/DeleteCustomer/"+ custId).
    pipe(tap(data => data.toString()))
  }
}
