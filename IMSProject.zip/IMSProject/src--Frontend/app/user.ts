export class User {

    public  custId : number;
    public  custName : string;
    public  mail : string;
    public  mobileno : string;
    public  dob : Date;
    public  gender : string;
    public  address : string;
    public  username : string;
    public  pwd : string;
}
