import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  constructor() { }

  onLogout(){
    if
      (window.confirm('Are you sure , you want to logout')){
        localStorage.removeItem('user1');
      }

      
    }

  ngOnInit(): void {
  }


}
