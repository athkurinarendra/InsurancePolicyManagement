import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { Apolicies } from './apolicies';
import { Policy } from './policy';

@Injectable({
  providedIn: 'root'
})
export class ApoliciesService {

  constructor(private _http: HttpClient) { }
  showAPolicies(): Observable<Apolicies []> {
    return this._http.get<Apolicies []>("http://localhost:8080/AppliedPolicies")
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
}

getpolicybycid(custId : number) : Observable<Apolicies []>{
  return this._http.get<Apolicies[]>("http://localhost:8080/appliedpolicy/" + custId)
  .pipe(
    tap(data =>
    console.log('All: ' + JSON.stringify(data)))
  );
}

acceptOrReject(aid : number,status : string) : Observable<any> {
  return this._http.post("http://localhost:8080/acceptOrRejectOrder/"+aid+"/"+status,null ,  {"responseType": 'text'})
  .pipe(
    tap(data => {console.log("Place Order :"+data.toString()); return data.toString();})
  );
}

// getpolicy(pid : number) : Observable<Policy>{
//   return this._http.get<Policy>("http://localhost:8080/policy/" + pid)
// }

applypolicy(apolicy : Apolicies) : Observable<any> {
  return this._http.post<string>("http://localhost:8080/addappliedpolicy",apolicy).
  pipe(tap(data => data.toString()))
}


}
