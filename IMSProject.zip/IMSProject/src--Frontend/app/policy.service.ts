import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { Policy } from './policy';

@Injectable({
  providedIn: 'root'
})
export class PolicyService {


  constructor(private _http: HttpClient) { }
  showPolicies(): Observable<Policy []> {
    return this._http.get<Policy []>("http://localhost:8080/policies")
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
}


addpolicy(policy : Policy) : Observable<any> {
  return this._http.post<string>("http://localhost:8080/admin/addpolicy",policy).
  pipe(tap(data => data.toString()))
}

getpolicy(pid : number) : Observable<Policy>{
  return this._http.get<Policy>("http://localhost:8080/policy/" + pid)
}

updatepolicy(policy : Policy) : Observable<any> {
  return this._http.put<string>("http://localhost:8080/editpolicy",policy).
  pipe(tap(data => data.toString()))
}


applypolicy(policy : Policy) : Observable<any> {
  return this._http.post<string>("http://localhost:8080/addappliedpolicy",policy).
  pipe(tap(data => data.toString()))
}


}
