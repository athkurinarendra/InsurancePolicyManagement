import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Apolicies } from '../apolicies';
import { ApoliciesService } from '../apolicies.service';

@Component({
  selector: 'app-appliedpolicy',
  templateUrl: './appliedpolicy.component.html',
  styleUrls: ['./appliedpolicy.component.css']
})
export class AppliedpolicyComponent implements OnInit {

  apoliciess : Apolicies[];
  constructor(private _apolicyService :ApoliciesService,private _route : ActivatedRoute,private _router : Router) {

    this._apolicyService.showAPolicies().subscribe({
      next: rs =>{
        this.apoliciess = rs;
      }
    })
  }
  applicationId:number;

  acceptOrReject(aid : number) {
    this.applicationId=aid;
    localStorage.setItem("ApplicationId",this.applicationId.toString());
    this._router.navigate(['../acceptorreject'], {relativeTo: this._route});
 }
  ngOnInit(): void {
  }

}
