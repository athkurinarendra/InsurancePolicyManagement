export class Adminregister {
    
    public  adminId : number;
    public  aname : string;
    public  ausername : string;
    public  apassword : string;
}
