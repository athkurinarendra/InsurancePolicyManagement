import { Apolicies } from './apolicies';

describe('Apolicies', () => {
  it('should create an instance', () => {
    expect(new Apolicies()).toBeTruthy();
  });
});
