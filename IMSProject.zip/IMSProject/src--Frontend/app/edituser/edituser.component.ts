import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css']
})
export class EdituserComponent implements OnInit {

  public edituser! : FormGroup;
  user : User;
  result : any;
  custId : number;
  constructor(private _userService : UserService,private router : Router) { 
    this.user = new User();
  }

  update(edituser : NgForm){
    this._userService.updateuser(this.user).subscribe(x =>{
      this.result=x;
  })
  alert("User details Updated Successfully!!")
  this.router.navigate(['/userDashboard'])
  }

  ngOnInit(): void {
    let user2 = JSON.parse(localStorage.getItem("user2"))
    this.custId = parseInt(user2.custId)
    this._userService.getcustomer(this.custId).subscribe(x =>{
      this.user=x;})
  }

}
