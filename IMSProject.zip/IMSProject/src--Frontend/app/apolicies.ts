export class Apolicies {

    public  applicationId  : number;
    public  custId  : number;
    public  custName  : string;
    public  pname  : string;
    public  dateofapplied  : Date;
    public  pstatus  : string;
    public  reason  : string;
}
