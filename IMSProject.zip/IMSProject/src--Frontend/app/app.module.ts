import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { RegisterComponent } from './register/register.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { AdminregisterComponent } from './adminregister/adminregister.component';
import { UserregisterComponent } from './userregister/userregister.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { EdituserComponent } from './edituser/edituser.component';
import { PolicyComponent } from './policy/policy.component';
import { StatusComponent } from './status/status.component';
import { AppliedpolicyComponent } from './appliedpolicy/appliedpolicy.component';
import { HttpClientModule } from '@angular/common/http';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { RouterModule, Routes } from '@angular/router';
import { UserComponent } from './user/user.component';
import { AddpolicyComponent } from './addpolicy/addpolicy.component';
import { EditpolicyComponent } from './editpolicy/editpolicy.component';
import { ShowpolicyComponent } from './showpolicy/showpolicy.component';
import { AppliedpolicycustComponent } from './appliedpolicycust/appliedpolicycust.component';
import { AcceptorrejectComponent } from './acceptorreject/acceptorreject.component';
import { ApplyforpolicyComponent } from './applyforpolicy/applyforpolicy.component';
import { DeleteComponent } from './delete/delete.component';
import { DeleteuserComponent } from './deleteuser/deleteuser.component';


const appRoutes : Routes = [
  {path:'',component:HomeComponent},
  {path:'home',component:HomeComponent},
  {path:'Contactus',component:ContactusComponent},
  {path:'aboutus',component:AboutusComponent},
  {path:'adminlogin',component:AdminloginComponent},
  {path:'userlogin',component:UserloginComponent},
  {path:'AdminDashboard',component:AdminDashboardComponent},
  {path:'addpolicy',component:AddpolicyComponent},
  {path:'Update/:pid',component:EditpolicyComponent},
  {path:'ApplyPolicy/:pid',component:ApplyforpolicyComponent},
  {path:'Delete/:pid',component:DeleteComponent},
  {path:'DeleteCustomer/:pid',component:DeleteuserComponent},
  {path:'userDashboard',component:UserDashboardComponent, 
  children : [
    {path:'showpolicy',component:ShowpolicyComponent,outlet:'IMS'},
    {path:'showapolicy',component:AppliedpolicycustComponent,outlet:'IMS'},
    {path:'EditUser',component:EdituserComponent,outlet:'IMS'},
    {path:'home',component:HomeComponent,outlet:'IMS'},
    // {path:'policies',component:ShowpolicyComponent},

  ]  
},
{path:'adminDashboard',component:AdminDashboardComponent, 
children : [
  {path:'home',component:HomeComponent,outlet:'IMS'},
  {path:'Contactus',component:ContactusComponent,outlet:'IMS'},
  {path:'Aboutus',component:AboutusComponent,outlet:'IMS'},
  {path:'Availablepolicy',component:PolicyComponent,outlet:'IMS'},
  {path:'Delete',component:DeleteComponent,outlet:'IMS'},

  // {path:'Policystatus',component:StatusComponent,outlet:'mphasis'},
  {path:'AppliedPolicies',component:AppliedpolicyComponent,outlet:'IMS'},
  {path:'User',component:UserComponent,outlet:'IMS'},
  {path:'acceptorreject',component:AcceptorrejectComponent,outlet:'IMS'},

]  
}

]


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ContactusComponent,
    AboutusComponent,
    RegisterComponent,
    AdminloginComponent,
    UserloginComponent,
    AdminregisterComponent,
    UserregisterComponent,
    UserdetailsComponent,
    EdituserComponent,
    PolicyComponent,
    StatusComponent,
    AppliedpolicyComponent,
    UserDashboardComponent,
    AdminDashboardComponent,
    UserComponent,
    AddpolicyComponent,
    EditpolicyComponent,
    ShowpolicyComponent,
    AppliedpolicycustComponent,
    AcceptorrejectComponent,
    ApplyforpolicyComponent,
    DeleteComponent,
    DeleteuserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
