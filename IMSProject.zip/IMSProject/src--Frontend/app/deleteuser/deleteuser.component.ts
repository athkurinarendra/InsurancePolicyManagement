import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DeleteService } from '../delete.service';

@Component({
  selector: 'app-deleteuser',
  templateUrl: './deleteuser.component.html',
  styleUrls: ['./deleteuser.component.css']
})
export class DeleteuserComponent implements OnInit {

  constructor(private _deleteService : DeleteService,private router : Router) {
    let user2 = JSON.parse(localStorage.getItem("user2"))
    this.custId = parseInt(user2.custId)
   }

custId : number;
result : any;

  delete(){
    this._deleteService.deleteuser(this.custId).subscribe(x =>{
      this.result=x;
  })
  console.log("custId="+this.custId)
  alert("User Deleted Successfully!!")
  this.router.navigate(['/adminDashboard'])
  }
  ngOnInit(): void {
  }

}
