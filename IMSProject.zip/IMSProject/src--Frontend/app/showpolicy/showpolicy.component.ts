import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Policy } from '../policy';
import { PolicyService } from '../policy.service';

@Component({
  selector: 'app-showpolicy',
  templateUrl: './showpolicy.component.html',
  styleUrls: ['./showpolicy.component.css']
})
export class ShowpolicyComponent implements OnInit {

  policiess : Policy[];
  constructor(private _policyService :PolicyService,private router : Router) {

    this._policyService.showPolicies().subscribe({
      next: rs =>{
        this.policiess = rs;
      }
    });
    
  }
apply(pid : number){
  this.router.navigate(['/ApplyPolicy',pid]);

}
  ngOnInit(): void {
  }

}
