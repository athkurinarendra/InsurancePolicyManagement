import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-userregister',
  templateUrl: './userregister.component.html',
  styleUrls: ['./userregister.component.css']
})
export class UserregisterComponent implements OnInit {
  public loginForm! : FormGroup;
users : User;
result : any;

insert(){
  this._userregisterService.adduser(this.users).subscribe(x =>{
    this.result=x;
})
alert("User Added Successfully!!")
this.router.navigate(['/userlogin'])
}

constructor(private _userregisterService : UserService,private router : Router) {
  this.users = new User();
}

  ngOnInit(): void {
  }

}
