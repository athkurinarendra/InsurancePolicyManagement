package com.project.ims.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.project.ims.dao.AppliedpolicyDAO;
import com.project.ims.entity.Appliedpolicy;
@Service
@Transactional
public class AppliedpolicyService {
	
	@Autowired
	AppliedpolicyDAO dao;
	public Appliedpolicy[] showappliedPolicies() {
		return dao.showappliedPolicies();
	}

	public Appliedpolicy[] searchAPolicy(int CustId) {
		return dao.searchAPolicy(CustId);
	}
	
	
	public Appliedpolicy searchAPolicybyaid(int ApplicationId) {
		return dao.searchAPolicybyaid(ApplicationId);
	}
	
	public String AddappliedPolicy(Appliedpolicy appliedpolicies) {
		return dao.AddappliedPolicy(appliedpolicies);
	}
	
	public String acceptOrRejectOrder(int orderId, String status) {
		return dao.acceptOrRejectOrder(orderId, status);
	}
}
