package com.project.ims.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.project.ims.dao.CustomerDAO;
import com.project.ims.entity.Customer;



@Service
@Transactional
public class CustomerService {

	
	@Autowired
	CustomerDAO dao;
	
	public Customer[] showCustomer() {
		return dao.showCustomer();
	}
	
	public String AddUser(Customer customer) {
		return dao.AddUser(customer);
	}
	
	public Customer searchCustomer(int CustId) {
		return dao.searchCustomer(CustId);
	}
	public String Updateuser(Customer customer) {
		return dao.Updateuser(customer);
	}
	
	public String DeleteUser(int CustId) {
		return dao.DeleteUser(CustId);
	}
}