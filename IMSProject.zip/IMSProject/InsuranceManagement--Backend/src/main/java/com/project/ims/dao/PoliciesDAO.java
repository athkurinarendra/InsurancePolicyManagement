package com.project.ims.dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.project.ims.entity.Policies;


@Repository
public class PoliciesDAO {
	
	@Autowired
    JdbcTemplate jdbcTemplate;
	public Policies[] showPolicies() {
		String cmd = "select * from Policies";
		List<Policies> policiesList = null;
		policiesList = jdbcTemplate.query(cmd, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Policies policies = new Policies();
				policies = new Policies();
				policies.setPid(rs.getInt("pid"));
				policies.setPname(rs.getString("pname"));
				policies.setPcategory(rs.getString("pcategory"));
				policies.setAssurance(rs.getInt("assurance"));
				policies.setPremium(rs.getInt("premium"));
				policies.setTenure(rs.getInt("tenure"));
				policies.setDate_of_creation(rs.getDate("Date_of_creation"));
	
				
				
				return policies;
			}
		});
		return policiesList.toArray(new Policies[policiesList.size()]);
	}

	public String AddPolicy(Policies policy)  {
//		
//		java.util.Date today = new Date();
//		java.sql.Date dbDate = new java.sql.Date(today.getTime());
//		policy.setDate_of_creation(dbDate);
		
			String cmd = "insert into Policies(Pid,Pname,Pcategory,Assurance,"
					+ "Premium,Tenure,Date_of_creation) "
					+ "values(?,?,?,?,?,?,?)";
			jdbcTemplate.update(cmd, new Object[] {
				policy.getPid(), 
				policy.getPname(),
				policy.getPcategory(),
				policy.getAssurance(),
				policy.getPremium(),
				policy.getTenure(),
				policy.getDate_of_creation()
			});
			return "Policy Added Successfully..";
		
	}
	
	
	public String DeletePolicy(int Pid) {
		String cmd = "Delete from Policies where Pid=?";
		jdbcTemplate.update(cmd, new Object[] {Pid});
			return "Policy Deleted Successfully..";
	}
	
	
	public String Updatepolicy(Policies policy)  {
//		
//		java.util.Date today = new Date();
//		java.sql.Date dbDate = new java.sql.Date(today.getTime());
//		policy.setDate_of_creation(dbDate);
		
			String cmd = "Update Policies set Pname=?,Pcategory=?,Assurance=?,"
					+ "Premium=?,Tenure=?,Date_of_creation=? "
					+ "Where Pid=?";
			jdbcTemplate.update(cmd, new Object[] {
				policy.getPname(),
				policy.getPcategory(),
				policy.getAssurance(),
				policy.getPremium(),
				policy.getTenure(),
				policy.getDate_of_creation(),
				policy.getPid()
			});
			return "Policy Updated Successfully..";
		
	}
	
	
	public Policies searchPolicy(int Pid) {
		String cmd = "select * from Policies where Pid=?";
		List<Policies> policiesList = jdbcTemplate.query(cmd, new Object[] {Pid}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Policies policies = new Policies();
				policies = new Policies();
				policies.setPid(rs.getInt("pid"));
				policies.setPname(rs.getString("pname"));
				policies.setPcategory(rs.getString("pcategory"));
				policies.setAssurance(rs.getInt("assurance"));
				policies.setPremium(rs.getInt("premium"));
				policies.setTenure(rs.getInt("tenure"));
				policies.setDate_of_creation(rs.getDate("Date_of_creation"));
				return policies;
			}
		});
		if (policiesList.size()==1) {
			return policiesList.get(0);
		}
		return null;
	}

}

