package com.project.ims.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.ims.entity.Customer;
import com.project.ims.service.CustomerService;



@RestController
public class CustomerController {

	
	@Autowired
	private CustomerService customerService;
	
	@RequestMapping("/Customer")
	public Customer[] show() {
		return customerService.showCustomer();
		
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/adduser")
	public String add(@RequestBody Customer customer) {
	return customerService.AddUser(customer);
	}
	
@RequestMapping("/Customer/{CustId}")
public Customer searchCustomer(@PathVariable int CustId) {
	return customerService.searchCustomer(CustId);
}

@CrossOrigin(origins = "http://localhost:4200")
@PutMapping("/edituser")
public String Updateuser(@RequestBody Customer customer) {
return customerService.Updateuser(customer);
}

@CrossOrigin(origins = "http://localhost:4200")
@DeleteMapping("/DeleteCustomer/{CustId}")
public String DeleteUser(@PathVariable int CustId) {
return customerService.DeleteUser(CustId);
}

}
