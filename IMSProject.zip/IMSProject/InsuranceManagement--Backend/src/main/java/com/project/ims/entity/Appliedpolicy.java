package com.project.ims.entity;


import java.sql.Date;

public class Appliedpolicy {
	
	private int ApplicationId ;
	private int CustId  ;
	private String CustName  ;
	private String Pname  ;
	private Date Dateofapplied  ;
	private String Pstatus   ;
	private String Reason   ;
	public int getApplicationId() {
		return ApplicationId;
	}
	public void setApplicationId(int applicationId) {
		ApplicationId = applicationId;
	}
	public int getCustId() {
		return CustId;
	}
	public void setCustId(int custId) {
		CustId = custId;
	}
	public String getCustName() {
		return CustName;
	}
	public void setCustName(String custName) {
		CustName = custName;
	}
	public String getPname() {
		return Pname;
	}
	public void setPname(String pname) {
		Pname = pname;
	}
	public Date getDateofapplied() {
		return Dateofapplied;
	}
	public void setDateofapplied(Date dateofapplied) {
		Dateofapplied = dateofapplied;
	}
	public String getPstatus() {
		return Pstatus;
	}
	public void setPstatus(String pstatus) {
		Pstatus = pstatus;
	}
	public String getReason() {
		return Reason;
	}
	public void setReason(String reason) {
		Reason = reason;
	}
	@Override
	public String toString() {
		return "AppliedPolicy [ApplicationId=" + ApplicationId + ", CustId=" + CustId + ", CustName=" + CustName
				+ ", Pname=" + Pname + ", Dateofapplied=" + Dateofapplied + ", Pstatus=" + Pstatus + ", Reason="
				+ Reason + "]";
	}
	
	

}
