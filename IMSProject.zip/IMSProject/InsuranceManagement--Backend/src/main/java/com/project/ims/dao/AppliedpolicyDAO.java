package com.project.ims.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.project.ims.entity.Appliedpolicy;

@Repository
public class AppliedpolicyDAO {
	
	@Autowired
    JdbcTemplate jdbcTemplate;
	public Appliedpolicy[] showappliedPolicies() {
		String cmd = "select * from appliedpolicy";
		List<Appliedpolicy> appliedpoliciesList = null;
		appliedpoliciesList = jdbcTemplate.query(cmd, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Appliedpolicy appliedpolicies = new Appliedpolicy();
				appliedpolicies = new Appliedpolicy();
				appliedpolicies.setApplicationId(rs.getInt("applicationId"));
				appliedpolicies.setCustId(rs.getInt("custId"));
				appliedpolicies.setCustName(rs.getString("custName"));
				appliedpolicies.setPname(rs.getString("pname"));
				appliedpolicies.setDateofapplied(rs.getDate("dateofapplied"));
				appliedpolicies.setPstatus(rs.getString("pstatus"));
				appliedpolicies.setReason(rs.getString("reason"));
	
				
				
				return appliedpolicies;
			}
		});
		return appliedpoliciesList.toArray(new Appliedpolicy[appliedpoliciesList.size()]);
	}
	
	public Appliedpolicy[] searchAPolicy(int CustId) {
		String cmd = "select * from appliedpolicy where CustId=?";
		List<Appliedpolicy> appliedpoliciesList = jdbcTemplate.query(cmd, new Object[] {CustId}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Appliedpolicy appliedpolicies = new Appliedpolicy();
				appliedpolicies = new Appliedpolicy();
				appliedpolicies.setApplicationId(rs.getInt("applicationId"));
				appliedpolicies.setCustId(rs.getInt("custId"));
				appliedpolicies.setCustName(rs.getString("custName"));
				appliedpolicies.setPname(rs.getString("pname"));
				appliedpolicies.setDateofapplied(rs.getDate("dateofapplied"));
				appliedpolicies.setPstatus(rs.getString("pstatus"));
				appliedpolicies.setReason(rs.getString("reason"));
				return appliedpolicies;
			}
		});
		return appliedpoliciesList.toArray(new Appliedpolicy[appliedpoliciesList.size()]);
	}
	
	public String AddappliedPolicy(Appliedpolicy appliedpolicies)  {

		int aid = generateApplicationId();
		appliedpolicies.setPstatus("PENDING");
		java.util.Date today = new Date();
		java.sql.Date dbDate = new java.sql.Date(today.getTime());
		appliedpolicies.setDateofapplied(dbDate);
		appliedpolicies.setApplicationId(aid);
		
			String cmd = "insert into appliedpolicy(ApplicationId,CustId,CustName,Pname,"
					+ "Dateofapplied,Pstatus,Reason) "
					+ "values(?,?,?,?,?,?,?)";
			jdbcTemplate.update(cmd, new Object[] {
					appliedpolicies.getApplicationId(), 
					appliedpolicies.getCustId(),
					appliedpolicies.getCustName(),
					appliedpolicies.getPname(),
					appliedpolicies.getDateofapplied(),
					appliedpolicies.getPstatus(),
					appliedpolicies.getReason(),

			});
			return "AppliedPolicy Added Successfully..";
		
	}
	public int generateApplicationId()  {
		String cmd = "select case when max(ApplicationId) is NULL THEN 1"
				+ " else max(ApplicationId)+1 end aid from appliedpolicy";
		List<Object> aid = jdbcTemplate.query(cmd, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Object ob = rs.getInt("aid");
				return ob;
			}
		});
		return (Integer)aid.get(0);
	}
	
	
	public Appliedpolicy searchAPolicybyaid(int ApplicationId) {
		String cmd = "select * from appliedpolicy where ApplicationId=?";
		List<Appliedpolicy> appliedpoliciesList = jdbcTemplate.query(cmd, new Object[] {ApplicationId}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Appliedpolicy appliedpolicies = new Appliedpolicy();
				appliedpolicies = new Appliedpolicy();
				appliedpolicies.setApplicationId(rs.getInt("applicationId"));
				appliedpolicies.setCustId(rs.getInt("custId"));
				appliedpolicies.setCustName(rs.getString("custName"));
				appliedpolicies.setPname(rs.getString("pname"));
				appliedpolicies.setDateofapplied(rs.getDate("dateofapplied"));
				appliedpolicies.setPstatus(rs.getString("pstatus"));
				appliedpolicies.setReason(rs.getString("reason"));
				return appliedpolicies;
			}
		});
		return appliedpoliciesList.get(0);
	}
	
	public String acceptOrRejectOrder(int ApplicationId, String status) {
		Appliedpolicy appliedpolicies = searchAPolicybyaid(ApplicationId);

			if (status.toUpperCase().equals("YES")) {
				String cmd = "Update Appliedpolicy set Pstatus='ACCEPTED' "
						+ " WHERE ApplicationId=?";
				jdbcTemplate.update(cmd, new Object[] {ApplicationId});
				return "Policy Approved Successfully...";
			} else {
				String cmd = "Update Appliedpolicy set Pstatus='REJECTED' "
						+ " WHERE ApplicationId=?";
				jdbcTemplate.update(cmd,new Object[] {ApplicationId});
				return "Policy Rejected..";
			}
		
	}

}

