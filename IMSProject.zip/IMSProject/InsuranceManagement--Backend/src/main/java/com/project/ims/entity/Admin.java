package com.project.ims.entity;


import java.sql.Date;

public class Admin {
	private int AdminId ;
	private String Aname ;
	private String Ausername ;
	private String Apassword  ;
	public int getAdminId() {
		return AdminId;
	}
	public void setAdminId(int adminId) {
		AdminId = adminId;
	}
	public String getAname() {
		return Aname;
	}
	public void setAname(String aname) {
		Aname = aname;
	}
	public String getAusername() {
		return Ausername;
	}
	public void setAusername(String ausername) {
		Ausername = ausername;
	}
	public String getApassword() {
		return Apassword;
	}
	public void setApassword(String apassword) {
		Apassword = apassword;
	}
	@Override
	public String toString() {
		return "Admin [AdminId=" + AdminId + ", Aname=" + Aname + ", Ausername=" + Ausername + ", Apassword="
				+ Apassword + "]";
	}
}
