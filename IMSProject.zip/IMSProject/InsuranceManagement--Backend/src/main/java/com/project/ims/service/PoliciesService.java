package com.project.ims.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.project.ims.dao.PoliciesDAO;
import com.project.ims.entity.Policies;


@Service
@Transactional
public class PoliciesService {

	
	@Autowired
	PoliciesDAO dao;
	
	public Policies[] showPolicies() {
		return dao.showPolicies();
	}
	public String AddPolicy(Policies policy) {
		return dao.AddPolicy(policy);
	}
	
	public Policies searchPolicy(int Pid) {
		return dao.searchPolicy(Pid);
	}
	
	public String Updatepolicy(Policies policy) {
		return dao.Updatepolicy(policy);
	}
	
	public String DeletePolicy(int Pid) {
		return dao.DeletePolicy(Pid);
	}
}
