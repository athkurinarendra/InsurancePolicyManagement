package com.project.ims.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.project.ims.dao.AdminDAO;
import com.project.ims.entity.Admin;



@Service
@Transactional

public class AdminService {
	@Autowired
	AdminDAO dao;
	
	
	public String AddAdmin(Admin admin) {
		return dao.AddAdmin(admin);
	}
	
	
	public Admin[] showAdmin() {
		return dao.showAdmin();
	}
	

}