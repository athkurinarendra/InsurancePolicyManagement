package com.project.ims.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.ims.entity.Appliedpolicy;
import com.project.ims.service.AppliedpolicyService;
@RestController
public class AppliedpolicyController {
	
	@Autowired
	private AppliedpolicyService appliedpolicyService;
	
	@RequestMapping("/AppliedPolicies")
	public Appliedpolicy[] show() {
		return appliedpolicyService.showappliedPolicies();
		
	}
	
	@RequestMapping("/appliedpolicy/{CustId}")
	public Appliedpolicy[] searchAPolicy(@PathVariable int CustId) {
		return appliedpolicyService.searchAPolicy(CustId);
	}
	
	
	@RequestMapping("/appliedpolicybyaid/{ApplicationId}")
	public Appliedpolicy searchAPolicybyaid(@PathVariable int ApplicationId) {
		return appliedpolicyService.searchAPolicybyaid(ApplicationId);
	}
	
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/addappliedpolicy")
	public String add(@RequestBody Appliedpolicy appliedpolicies) {
	return appliedpolicyService.AddappliedPolicy(appliedpolicies);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/acceptOrRejectOrder/{ordId}/{status}")
	public String acceptOrRejectOrder(@PathVariable int ordId,@PathVariable String status) {
	return appliedpolicyService.acceptOrRejectOrder(ordId, status);
	}

}