package com.project.ims.dao;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.project.ims.entity.Admin;
import com.project.ims.entity.Customer;
@Repository
public class AdminDAO {
	
@Autowired
JdbcTemplate jdbcTemplate;	
	
	
	public String AddAdmin(Admin admin)  {
		
			String cmd = "insert into Admin(AdminId,Aname,Ausername,Apassword)"
					+ "values(?,?,?,?)";
			jdbcTemplate.update(cmd, new Object[] {
					admin.getAdminId(),
					admin.getAname(),
					admin.getAusername(),
					admin.getApassword()
			});
			return "Admin Added Successfully..";
		
	}
	
//	public int generateAdminId()  {
//		String cmd = "select case when max(AdminId) is NULL THEN 1"
//				+ " else max(AdminId)+1 end aid from Admin";
//		List<Object> aid = jdbcTemplate.query(cmd, new RowMapper() {
//
//			@Override
//			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
//				Object ob = rs.getInt("aid");
//				return ob;
//			}
//		});
//		return (Integer)aid.get(0);
//	}
//	
	
	
	
	@Autowired
	public Admin[] showAdmin() {
		String cmd = "select * from Admin";
		List<Admin> adminList = null;
		adminList = jdbcTemplate.query(cmd, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Admin admin = new Admin();
				admin = new Admin();
				admin.setAdminId(rs.getInt("adminId"));
				admin.setAname(rs.getString("aname"));
				admin.setAusername(rs.getString("ausername"));
				admin.setApassword(rs.getString("apassword"));
				
				
				return admin;
			}
		});
		return adminList.toArray(new Admin[adminList.size()]);
	}

}