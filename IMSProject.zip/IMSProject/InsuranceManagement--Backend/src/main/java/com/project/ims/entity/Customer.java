package com.project.ims.entity;


import java.sql.Date;

public class Customer {
	
	private int CustId  ;
	private String CustName  ;
	private String Mail  ;
	private String Mobileno  ;
	private Date DOB  ;
	private String Gender   ;
	private String Address   ;
	private String Username   ;
	private String Pwd   ;
	public int getCustId() {
		return CustId;
	}
	public void setCustId(int custId) {
		CustId = custId;
	}
	public String getCustName() {
		return CustName;
	}
	public void setCustName(String custName) {
		CustName = custName;
	}
	public String getMail() {
		return Mail;
	}
	public void setMail(String mail) {
		Mail = mail;
	}
	public String getMobileno() {
		return Mobileno;
	}
	public void setMobileno(String mobileno) {
		Mobileno = mobileno;
	}
	public Date getDOB() {
		return DOB;
	}
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPwd() {
		return Pwd;
	}
	public void setPwd(String pwd) {
		Pwd = pwd;
	}
	@Override
	public String toString() {
		return "Customer [CustId=" + CustId + ", CustName=" + CustName + ", Mail=" + Mail + ", Mobileno=" + Mobileno
				+ ", DOB=" + DOB + ", Gender=" + Gender + ", Address=" + Address + ", Username=" + Username + ", Pwd="
				+ Pwd + "]";
	}
	
	
}

