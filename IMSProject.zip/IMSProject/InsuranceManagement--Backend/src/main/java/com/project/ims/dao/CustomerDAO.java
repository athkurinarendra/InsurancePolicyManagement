package com.project.ims.dao;

import java.sql.ResultSet;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.project.ims.entity.Customer;


@Repository
public class CustomerDAO {
	@Autowired
    JdbcTemplate jdbcTemplate;
	public Customer[] showCustomer() {
		String cmd = "select * from Customer";
		List<Customer> customerList = null;
		customerList = jdbcTemplate.query(cmd, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Customer customer = new Customer();
				customer = new Customer();
				customer.setCustId(rs.getInt("custId"));
				customer.setCustName(rs.getString("custName"));
				customer.setUsername(rs.getString("username"));
				customer.setMail(rs.getString("mail"));
				customer.setMobileno(rs.getString("mobileno"));
				customer.setPwd(rs.getString("Pwd"));
				customer.setDOB(rs.getDate("dOB"));
				customer.setGender(rs.getString("gender"));
				customer.setAddress(rs.getString("address"));
				
				return customer;
			}
		});
		return customerList.toArray(new Customer[customerList.size()]);
	}
	
	
	public String AddUser(Customer customer)  {
		
		int cid = generateCustomerId();
		customer.setCustId(cid);
			String cmd = "insert into Customer(CustId,CustName,Username,Mail,Mobileno,Pwd,DOB,Gender,Address)"
					+ "values(?,?,?,?,?,?,?,?,?)";
			jdbcTemplate.update(cmd, new Object[] {
					customer.getCustId(),
					customer.getCustName(),
					customer.getUsername(),
					customer.getMail(),
					customer.getMobileno(),
					customer.getPwd(),
					customer.getDOB(),
					customer.getGender(),
					customer.getAddress()
			});
			return "User Added Successfully..";
		
	}
	
	public int generateCustomerId()  {
		String cmd = "select case when max(CustId) is NULL THEN 1"
				+ " else max(CustId)+1 end cid from Customer";
		List<Object> cid = jdbcTemplate.query(cmd, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Object ob = rs.getInt("cid");
				return ob;
			}
		});
		return (Integer)cid.get(0);
	}
	
	
	
	
	public Customer searchCustomer(int CustId) {
		String cmd = "select * from Customer where CustId=?";
		List<Customer> customerList = jdbcTemplate.query(cmd, new Object[] {CustId}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Customer customer = new Customer();
				customer = new Customer();
				customer.setCustId(rs.getInt("custId"));
				customer.setCustName(rs.getString("custName"));
				customer.setUsername(rs.getString("username"));
				customer.setMail(rs.getString("mail"));
				customer.setMobileno(rs.getString("mobileno"));
				customer.setPwd(rs.getString("Pwd"));
				customer.setDOB(rs.getDate("dOB"));
				customer.setGender(rs.getString("gender"));
				customer.setAddress(rs.getString("address"));
				return customer;
			}
		});
		if (customerList.size()==1) {
			return customerList.get(0);
		}
		return null;
	}
	
	public String Updateuser(Customer customer)  {

			String cmd = "Update Customer set CustName=?,Username=?,"
					+ "Mail=?,Mobileno=?,Pwd=?,DOB=?,Gender=?,Address=? "
					+ "Where CustId=?";
			jdbcTemplate.update(cmd, new Object[] {
					customer.getCustName(),
					customer.getUsername(),
					customer.getMail(),
					customer.getMobileno(),
					customer.getPwd(),
					customer.getDOB(),
					customer.getGender(),
					customer.getAddress(),
					customer.getCustId()

			});
			return "User Updated Successfully..";
		
	}
	
	public String DeleteUser(int CustId) {
		String cmd = "Delete from Customer where CustId=?";
		jdbcTemplate.update(cmd, new Object[] {CustId});
			return "Customer Deleted Successfully..";
	}
	
	
}