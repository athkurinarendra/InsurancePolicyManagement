package com.project.ims;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.project.ims.dao.PoliciesDAO;
import com.project.ims.entity.Policies;

@SpringBootTest(classes=Policies.class)
class InsuranceManagementApplicationTests {

	@Autowired
	PoliciesDAO pdao;
	@Test
	public void searchPolicy() {
		Policies p=pdao.findbyId(2).get();
		 assertEquals("dosa",p.getPname());
	}
	

}
