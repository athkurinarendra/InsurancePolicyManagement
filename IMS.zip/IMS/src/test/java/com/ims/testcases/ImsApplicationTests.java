package com.ims.testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;


import com.ims.ImsApplication;
import com.ims.entity.Policies;
import com.ims.DAO.PoliciesDAO;
import com.ims.Service.PoliciesService;

@RunWith(SpringRunner.class)
@SpringBootTest
class ImsApplicationTests {
	@Autowired
	private PoliciesService Service;
	@MockBean PoliciesDAO DAO;
	
	@Test
	public void addPolicies() {
		Policies Policies = new Policies();
		Policies.setPid(1);
		Policies.setPname("mypolicy");
		Policies.setPcategory("health");
		Policies.setAssurance(22);
		Policies.setPremium(4500);
		Policies.setTenure(889);
		//Policies.setDate_of_creation();
		assertNotNull(Policies);
		assertEquals(1,Policies.getPid());
	}
}