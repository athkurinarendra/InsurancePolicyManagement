package com.ims.Service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ims.entity.Customer;
import com.ims.DAO.CustomerDAO;

@Service
@Transactional
public class CustomerService {

	
	@Autowired
	CustomerDAO dao;
	
	public Customer[] showCustomer() {
		return dao.showCustomer();
	}
	
	public String AddUser(Customer customer) {
		return dao.AddUser(customer);
	}
	public Customer searchCustomer(int CustId) {
		return dao.searchCustomer(CustId);
	}

}
