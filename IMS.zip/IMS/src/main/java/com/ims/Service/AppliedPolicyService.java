package com.ims.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ims.DAO.AppliedPolicyDAO;
import com.ims.entity.AppliedPolicy;
@Service
@Transactional
public class AppliedPolicyService {
	
	@Autowired
	AppliedPolicyDAO dao;
	public AppliedPolicy[] showappliedPolicies() {
		return dao.showappliedPolicies();
	}

	public AppliedPolicy[] searchAPolicy(int CustId) {
		return dao.searchAPolicy(CustId);
	}
	
	
	public AppliedPolicy searchAPolicybyaid(int ApplicationId) {
		return dao.searchAPolicybyaid(ApplicationId);
	}
	
	public String AddappliedPolicy(AppliedPolicy appliedpolicies) {
		return dao.AddappliedPolicy(appliedpolicies);
	}
	
	public String acceptOrRejectOrder(int orderId, String status) {
		return dao.acceptOrRejectOrder(orderId, status);
	}
}
