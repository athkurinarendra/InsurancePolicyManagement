package com.ims.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ims.entity.Customer;
import com.ims.entity.Policies;
import com.ims.DAO.CustomerDAO;
import com.ims.DAO.PoliciesDAO;

@Service
@Transactional
public class PoliciesService {

	
	@Autowired
	 private PoliciesDAO dao;
	
	
	public Policies[] showPolicies() {
		List<Policies> policiesList = dao.showPolicies();
		return policiesList.toArray(new Policies[policiesList.size()]);
	}

	public String AddPolicy(Policies policy) {
		return dao.AddPolicy(policy);
	}
	
	public Policies searchPolicy(int Pid) {
		return dao.searchPolicy(Pid);
	}
	public String Updatepolicy(Policies policy) {
		return dao.Updatepolicy(policy);
	}
	//public void deletePolicy(int pid) {
		 //dao.deletePolicyDAO(pid);
	//}


	
}
