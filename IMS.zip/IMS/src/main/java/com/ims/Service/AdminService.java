package com.ims.Service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.ims.entity.Admin;
import com.ims.DAO.AdminDAO;

@Service
@Transactional

public class AdminService {
	@Autowired
	AdminDAO dao;
	
	
	public String AddAdmin(Admin admin) {
		return dao.AddAdmin(admin);
	}
	
	
	public Admin[] showAdmin() {
		return dao.showAdmin();
	}
	

}
