package com.ims.DAO;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ims.entity.Policies;
@Repository
public class PoliciesDAO {
	@PersistenceContext
	private EntityManager em;
	
	@Autowired
    JdbcTemplate jdbcTemplate;
	private final String DELETE_POLICIES="DELETE From Doctor WHERE pid=?";

	public List <Policies> showPolicies() {
		String cmd = "select * from Policies";
		List<Policies> policiesList = jdbcTemplate.query(cmd, new RowMapper() 
		 {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Policies policies = new Policies();
				policies = new Policies();
				policies.setPid(rs.getInt("pid"));
				policies.setPname(rs.getString("pname"));
				policies.setPcategory(rs.getString("pcategory"));
				policies.setAssurance(rs.getInt("assurance"));
				policies.setPremium(rs.getInt("premium"));
				policies.setTenure(rs.getInt("tenure"));
				policies.setDate_of_creation(rs.getDate("Date_of_creation"));
	            return policies;
			}
		});
		return policiesList;
	}
	
	public String AddPolicy(Policies policy)  {
		int newpid = generatepid();

//		java.util.Date today = new Date();
//		java.sql.Date dbDate = new java.sql.Date(today.getTime());
//		policy.setDate_of_creation(dbDate);
		
			String cmd = "insert into Policies(Pid,Pname,Pcategory,Assurance,"
					+ "Premium,Tenure,Date_of_creation) "
					+ "values(?,?,?,?,?,?,?)";
			jdbcTemplate.update(cmd, new Object[] {
				policy.getPid(), 
				policy.getPname(),
				policy.getPcategory(),
				policy.getAssurance(),
				policy.getPremium(),
				policy.getTenure(),
				policy.getDate_of_creation()
			});
			return "Policy details added. pid = "+newpid;

		
	}
	
	private int generatepid() {
		String command = "select nvl(max(pid),0) + 1 as newpid from Policy";
		
		return jdbcTemplate.query(command,new ResultSetExtractor<Integer>() {
			@Override
			public Integer extractData(ResultSet rs) throws SQLException, DataAccessException {
				rs.next();
				return rs.getInt("newpid");
			}
		});
	}

	public String Updatepolicy(Policies policy)  {
//		
//		java.util.Date today = new Date();
//		java.sql.Date dbDate = new java.sql.Date(today.getTime());
//		policy.setDate_of_creation(dbDate);
		
			String cmd = "Update Policies set Pname=?,Pcategory=?,Assurance=?,"
					+ "Premium=?,Tenure=?,Date_of_creation=? "
					+ "Where Pid=?";
			jdbcTemplate.update(cmd, new Object[] {
				policy.getPname(),
				policy.getPcategory(),
				policy.getAssurance(),
				policy.getPremium(),
				policy.getTenure(),
				policy.getDate_of_creation(),
				policy.getPid()
			});
			return "Policy Updated Successfully..";
		
	}
	
	
	public Policies searchPolicy(int Pid) {
		String cmd = "select * from Policies where Pid=?";
		List<Policies> policiesList = jdbcTemplate.query(cmd, new Object[] {Pid}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Policies policies = new Policies();
				policies = new Policies();
				policies.setPid(rs.getInt("pid"));
				policies.setPname(rs.getString("pname"));
				policies.setPcategory(rs.getString("pcategory"));
				policies.setAssurance(rs.getInt("assurance"));
				policies.setPremium(rs.getInt("premium"));
				policies.setTenure(rs.getInt("tenure"));
				policies.setDate_of_creation(rs.getDate("Date_of_creation"));
				return policies;
			}
		});
		return policiesList.get(0);
		
		//public void deletePoliciesDAO(int pid){
     		
        	 //jdbcTemplate.update(DELETE_Policy,pid);
     		//System.out.println("Deleted Successfully");
				
     		//};
     		

		
			
	}
	

	

	
	

	
	
}
