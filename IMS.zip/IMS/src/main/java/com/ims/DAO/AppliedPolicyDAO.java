package com.ims.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.ims.entity.AppliedPolicy;

@Repository
public class AppliedPolicyDAO {
	
	@Autowired
    JdbcTemplate jdbcTemplate;
	public AppliedPolicy[] showappliedPolicies() {
		String cmd = "select * from appliedpolicy";
		List<AppliedPolicy> appliedpoliciesList = null;
		appliedpoliciesList = jdbcTemplate.query(cmd, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				AppliedPolicy appliedpolicies = new AppliedPolicy();
				appliedpolicies = new AppliedPolicy();
				appliedpolicies.setApplicationId(rs.getInt("applicationId"));
				appliedpolicies.setCustId(rs.getInt("custId"));
				appliedpolicies.setCustName(rs.getString("custName"));
				appliedpolicies.setPname(rs.getString("pname"));
				appliedpolicies.setDateofapplied(rs.getDate("dateofapplied"));
				appliedpolicies.setPstatus(rs.getString("pstatus"));
				appliedpolicies.setReason(rs.getString("reason"));
	
				
				
				return appliedpolicies;
			}
		});
		return appliedpoliciesList.toArray(new AppliedPolicy[appliedpoliciesList.size()]);
	}
	
	public AppliedPolicy[] searchAPolicy(int CustId) {
		String cmd = "select * from appliedpolicy where CustId=?";
		List<AppliedPolicy> appliedpoliciesList = jdbcTemplate.query(cmd, new Object[] {CustId}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				AppliedPolicy appliedpolicies = new AppliedPolicy();
				appliedpolicies = new AppliedPolicy();
				appliedpolicies.setApplicationId(rs.getInt("applicationId"));
				appliedpolicies.setCustId(rs.getInt("custId"));
				appliedpolicies.setCustName(rs.getString("custName"));
				appliedpolicies.setPname(rs.getString("pname"));
				appliedpolicies.setDateofapplied(rs.getDate("dateofapplied"));
				appliedpolicies.setPstatus(rs.getString("pstatus"));
				appliedpolicies.setReason(rs.getString("reason"));
				return appliedpolicies;
			}
		});
		return appliedpoliciesList.toArray(new AppliedPolicy[appliedpoliciesList.size()]);
	}
	
	public String AddappliedPolicy(AppliedPolicy appliedpolicies)  {

		
			String cmd = "insert into appliedpolicy(ApplicationId,CustId,CustName,Pname,"
					+ "Dateofapplied,Pstatus,Reason) "
					+ "values(?,?,?,?,?,?,?)";
			jdbcTemplate.update(cmd, new Object[] {
					appliedpolicies.getApplicationId(), 
					appliedpolicies.getCustId(),
					appliedpolicies.getCustName(),
					appliedpolicies.getPname(),
					appliedpolicies.getDateofapplied(),
					appliedpolicies.getPstatus(),
					appliedpolicies.getReason(),

			});
			return "AppliedPolicy Added Successfully..";
		
	}
	
	
	public AppliedPolicy searchAPolicybyaid(int ApplicationId) {
		String cmd = "select * from appliedpolicy where ApplicationId=?";
		List<AppliedPolicy> appliedpoliciesList = jdbcTemplate.query(cmd, new Object[] {ApplicationId}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				AppliedPolicy appliedpolicies = new AppliedPolicy();
				appliedpolicies = new AppliedPolicy();
				appliedpolicies.setApplicationId(rs.getInt("applicationId"));
				appliedpolicies.setCustId(rs.getInt("custId"));
				appliedpolicies.setCustName(rs.getString("custName"));
				appliedpolicies.setPname(rs.getString("pname"));
				appliedpolicies.setDateofapplied(rs.getDate("dateofapplied"));
				appliedpolicies.setPstatus(rs.getString("pstatus"));
				appliedpolicies.setReason(rs.getString("reason"));
				return appliedpolicies;
			}
		});
		return appliedpoliciesList.get(0);
	}
	
	public String acceptOrRejectOrder(int ApplicationId, String status) {
		AppliedPolicy appliedpolicies = searchAPolicybyaid(ApplicationId);

			if (status.toUpperCase().equals("YES")) {
				String cmd = "Update Appliedpolicy set Pstatus='ACCEPTED' "
						+ " WHERE ApplicationId=?";
				jdbcTemplate.update(cmd, new Object[] {ApplicationId});
				return "Policy Approved Successfully...";
			} else {
				String cmd = "Update Appliedpolicy set Pstatus='REJECTED' "
						+ " WHERE ApplicationId=?";
				jdbcTemplate.update(cmd,new Object[] {ApplicationId});
				return "Policy Rejected..";
			}
		
	}

}
