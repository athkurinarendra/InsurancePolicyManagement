package com.ims.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ims.Service.AdminService;
import com.ims.entity.Admin;


@RestController

public class AdminController {
	
	
	@Autowired
	private AdminService adminService;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/addadmin")
	public String add(@RequestBody Admin admin) {
	return adminService.AddAdmin(admin);
	}
	
	
	@RequestMapping("/admin")
	public Admin[] show() {
		return adminService.showAdmin();
		
	}

}
