package com.ims.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ims.Service.AppliedPolicyService;
import com.ims.entity.AppliedPolicy;
@RestController
public class AppliedPolicyController {
	
	@Autowired
	private AppliedPolicyService appliedpolicyService;
	
	@RequestMapping("/AppliedPolicies")
	public AppliedPolicy[] show() {
		return appliedpolicyService.showappliedPolicies();
		
	}
	
	@RequestMapping("/appliedpolicy/{CustId}")
	public AppliedPolicy[] searchAPolicy(@PathVariable int CustId) {
		return appliedpolicyService.searchAPolicy(CustId);
	}
	
	
	@RequestMapping("/appliedpolicybyaid/{ApplicationId}")
	public AppliedPolicy searchAPolicybyaid(@PathVariable int ApplicationId) {
		return appliedpolicyService.searchAPolicybyaid(ApplicationId);
	}
	
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/addappliedpolicy")
	public String add(@RequestBody AppliedPolicy appliedpolicies) {
	return appliedpolicyService.AddappliedPolicy(appliedpolicies);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/acceptOrRejectOrder/{ordId}/{status}")
	public String acceptOrRejectOrder(@PathVariable int ordId,@PathVariable String status) {
	return appliedpolicyService.acceptOrRejectOrder(ordId, status);
	}

}
