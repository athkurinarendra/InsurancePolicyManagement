package com.ims.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ims.entity.Customer;
import com.ims.entity.Policies;
import com.ims.Service.CustomerService;
import com.ims.Service.PoliciesService;


@RestController
public class PoliciesController {

	
	@Autowired
	private PoliciesService policiesService;
	
	@RequestMapping("/policies")
	public Policies[] show() {
		return policiesService.showPolicies();
		
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/admin/addpolicy")
	public String add(@RequestBody Policies policy) {
	return policiesService.AddPolicy(policy);
	}
	
@RequestMapping("/policy/{Pid}")
public Policies searchPolicy(@PathVariable int Pid) {
	return policiesService.searchPolicy(Pid);
}

@CrossOrigin(origins = "http://localhost:4200")
@PutMapping("/editpolicy")
public String Updatepolicy(@RequestBody Policies policy) {
return policiesService.Updatepolicy(policy);
}

}
