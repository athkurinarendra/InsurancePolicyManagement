package com.ims.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ims.entity.Customer;
import com.ims.Service.CustomerService;


@RestController
public class CustomerController {

	
	@Autowired
	private CustomerService customerService;
	
	@RequestMapping("/Customer")
	public Customer[] show() {
		return customerService.showCustomer();
		
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/adduser")
	public String add(@RequestBody Customer customer) {
	return customerService.AddUser(customer);
	}
	@RequestMapping("/Customer/{CustId}")
	public Customer searchCustomer(@PathVariable int CustId) {
		return customerService.searchCustomer(CustId);
	}

}
