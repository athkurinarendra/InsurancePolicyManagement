package com.ims.entity;

import java.sql.Date;

public class Policies {
	
	private int Pid;
	private String Pname ;
	private String Pcategory ;
	private int Assurance ;
	private int Premium ;
	private int Tenure ;
	private Date Date_of_creation ;
	public int getPid() {
		return Pid;
	}
	public void setPid(int pid) {
		Pid = pid;
	}
	public String getPname() {
		return Pname;
	}
	public void setPname(String pname) {
		Pname = pname;
	}
	public String getPcategory() {
		return Pcategory;
	}
	public void setPcategory(String pcategory) {
		Pcategory = pcategory;
	}
	public int getAssurance() {
		return Assurance;
	}
	public void setAssurance(int assurance) {
		Assurance = assurance;
	}
	public int getPremium() {
		return Premium;
	}
	public void setPremium(int premium) {
		Premium = premium;
	}
	public int getTenure() {
		return Tenure;
	}
	public void setTenure(int tenure) {
		Tenure = tenure;
	}
	public Date getDate_of_creation() {
		return Date_of_creation;
	}
	public void setDate_of_creation(Date date_of_creation) {
		Date_of_creation = date_of_creation;
	}
	@Override
	public String toString() {
		return "Policies [Pid=" + Pid + ", Pname=" + Pname + ", Pcategory=" + Pcategory + ", Assurance=" + Assurance
				+ ", Premium=" + Premium + ", Tenure=" + Tenure + ", Date_of_creation=" + Date_of_creation + "]";
	}

	
}
