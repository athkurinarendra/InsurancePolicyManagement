import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, NgForm} from '@angular/forms';
import { Router } from '@angular/router';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';
import { AdminregisterService } from '../adminregister.service';


@Component({
  selector: 'app-adminregister',
  templateUrl: './adminregister.component.html',
  styleUrls: ['./adminregister.component.css']
})
export class AdminregisterComponent implements OnInit {
  public loginForm! : FormGroup;
admins : Admin;
result : any;

// AdminId : number;
// Aname : string;
// Ausername : string;
// Apassword : string;

insert(AddAdmin : NgForm){
  this._adminregisterService.AddAdmin(this.admins).subscribe(x =>{
    this.result=x;
})
alert("Admin Added Successfully!!")
this.router.navigate(['/home'])
}

constructor(private _adminregisterService : AdminregisterService,private router : Router) {
  this.admins = new Admin();
}

  ngOnInit(): void {
  }
}
