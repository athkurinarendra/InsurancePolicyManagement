import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminregisterComponent } from './adminregister/adminregister.component';
import { ContactusComponent } from './contactus/contactus.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UserregisterComponent } from './userregister/userregister.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { EdituserComponent } from './edituser/edituser.component';
import { StatusComponent } from './status/status.component';
import { PolicyComponent } from './policy/policy.component';
import { AppliedpolicyComponent } from './appliedpolicy/appliedpolicy.component';

const routes: Routes = [
  {path: '' , component: HomeComponent },
  {path: 'home' , component: HomeComponent },
  {path: 'aboutus' , component: AboutusComponent},
  {path: 'contactus' , component: ContactusComponent},
  {path:'register',component:RegisterComponent},
  {path: 'adminlogin',component:AdminloginComponent},
  {path:'userlogin',component:UserloginComponent},
  {path: 'adminregister',component:AdminregisterComponent},
  {path:'userregister',component:UserregisterComponent},
  {path: 'userdetails',component:UserdetailsComponent},
  {path: 'edituser',component:EdituserComponent},
  {path: 'status',component:StatusComponent},
  {path: 'policy',component:PolicyComponent},
  {path:'appliedpolicy',component:AppliedpolicyComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
