import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

import { FormBuilder, FormGroup, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {

  public loginForm! : FormGroup
  constructor(private formBuilder : FormBuilder,private http : HttpClient,private router:Router) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username : [''],
      pwd : ['']
    
    })
      }

  
  onLogin(){
    this.http.get<any>("http://localhost:8080/Customer")
    .subscribe(res=>{
      const user2 = res.find((a:any)=>{
        return a.username === this.loginForm.value.username && a.pwd === this.loginForm.value.pwd
      });
      if(user2){
        alert("Login success...");
        localStorage.setItem('user2',JSON.stringify(user2));
        this.loginForm.reset();
        this.router.navigate(['/userDashboard'])
      }else{
        alert("User not found...")
      }
    })
     }
 



     
     
}
