export class Policy {

    public  pid  : number;
    public  pname  : string;
    public  pcategory  : string;
    public  assurance  : number;
    public  premium  : number;
    public  tenure  : number;
    public  date_of_creation  : Date;
}
