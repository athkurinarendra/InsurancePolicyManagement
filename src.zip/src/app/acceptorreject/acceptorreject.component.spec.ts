import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcceptorrejectComponent } from './acceptorreject.component';

describe('AcceptorrejectComponent', () => {
  let component: AcceptorrejectComponent;
  let fixture: ComponentFixture<AcceptorrejectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AcceptorrejectComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AcceptorrejectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
