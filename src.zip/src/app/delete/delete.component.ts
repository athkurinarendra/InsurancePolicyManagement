import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DeleteService } from '../delete.service';
import { Policy } from '../policy';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  constructor(private _deleteService : DeleteService,private router : Router) {

    this.pid = parseInt(localStorage.getItem("PolicyId"));
   }
  policy : Policy;
  result : any;
  pid : number;

  delete(){
    this._deleteService.deletepolicy(this.pid).subscribe(x =>{
      this.result=x;
  })
  console.log("pid="+this.pid)
  alert("Policy Deleted Successfully!!")
  this.router.navigate(['/adminDashboard'])
  }
  

  ngOnInit(): void {
  }

}
