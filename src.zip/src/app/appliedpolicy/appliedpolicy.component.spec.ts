import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppliedpolicyComponent } from './appliedpolicy.component';

describe('AppliedpolicyComponent', () => {
  let component: AppliedpolicyComponent;
  let fixture: ComponentFixture<AppliedpolicyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppliedpolicyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppliedpolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
