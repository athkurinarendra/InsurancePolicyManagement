import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { Admin } from './admin';

@Injectable({
  providedIn: 'root'
})
export class AdminregisterService {

  constructor(private _http: HttpClient) { }

  AddAdmin(admin : Admin) : Observable<any> {
    return this._http.post<string>("http://localhost:8080/addadmin",admin).
    pipe(tap(data => data.toString()))
  }
  
}
