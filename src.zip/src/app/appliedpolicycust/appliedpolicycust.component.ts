import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Apolicies } from '../apolicies';
import { ApoliciesService } from '../apolicies.service';

@Component({
  selector: 'app-appliedpolicycust',
  templateUrl: './appliedpolicycust.component.html',
  styleUrls: ['./appliedpolicycust.component.css']
})
export class AppliedpolicycustComponent implements OnInit {


  apoliciess : Apolicies [];
  custId : number;
  constructor(private _apolicyService :ApoliciesService,private router : Router) {
    let user2 = JSON.parse(localStorage.getItem("user2"))
    this.custId = parseInt(user2.custId)

    this._apolicyService.getpolicybycid(this.custId).subscribe({
      next: rs =>{
        this.apoliciess = rs;
      }
    })
  }

  ngOnInit(): void {
  }

}
