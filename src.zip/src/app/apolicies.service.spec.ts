import { TestBed } from '@angular/core/testing';

import { ApoliciesService } from './apolicies.service';

describe('ApoliciesService', () => {
  let service: ApoliciesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ApoliciesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
